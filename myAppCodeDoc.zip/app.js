const http = require('http');

const port = process.env.PORT;

const server = http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('Hello from Elastic Beanstalk Working App');
});

server.listen(port);